# Registro de Cambios (CHANGELOG) — Política Canon

Todas las modificaciones notables introducidas en este proyecto serán documentadas en este archivo.

El formato está basado en [Keep a Changelog](https://keepachangelog.com/es-ES/1.0.0/), y este proyecto adhiere a [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [0.2.14] - 2026-09-15

### Añadido y Remediado (Cierre Integral de Auditoría v0.2.9)
- **Recalculación Criptográfica en SQL y Transacción TS (C-01):** `verify_audit_chain` en PL/pgSQL recalcula el hash SHA-256 usando `digest(..., 'sha256')` de `pgcrypto`. En `src/audit/worker.ts`, `verifyAuditChainCrypted` ejecuta `set_config` dentro de una transacción explícita `BEGIN...COMMIT` evitando pérdidas de contexto RLS.
- **Validación de Ámbitos y Prohibición Estricta de Admin (C-02):** `evaluateAuthorizationContract` valida `ra.scopeId === resource.workspaceId` en `PUBLISH`, inspecciona `effectiveRoleAssignments` para la prohibición incondicional de Admin, deniega `AUDITOR` sin asignación persistida y valida `target_authority_body_id` en solicitudes de rol `APPROVER`.
- **Protección Trigger contra Mutaciones de Status (C-03):** Añadido trigger BEFORE UPDATE `trg_protect_document_status` en `documents` que impide alterar `status` directamente fuera de funciones transaccionales de servidor.
- **Revocación Estricta de PUBLIC y Aislamiento Worker (C-04):** Ejecutado `REVOKE ALL ON FUNCTION ... FROM PUBLIC` en todas las funciones elevadas. `get_pending_outbox_tenants()` revocada a `app_user` y restringida al rol `audit_worker`.
- **Ownership Real de Esquema y Objetos (C-05):** Añadidas sentencias `ALTER SCHEMA public OWNER TO app_owner`, `ALTER TABLE ... OWNER TO app_owner` para las 30 tablas y funciones.
- **Validador con Compilación TypeScript Nativa (H-01, H-02):** `scratch/validate_v0.2.14.cjs` ejecuta `npm run typecheck` (`tsc --noEmit`), suite de autorización con pruebas de denegación adversarial, y verificación criptográfica estricta SHA-256 de los 17 informes históricos (`v0.2.1` a `v0.2.9`). Creado `package-lock.json` determinista.
- **Manifiesto Externo y Rollback de Roles (H-03, H-05):** Creados `MANIFEST_v0.2.14.json` y `db/bootstrap_roles_down.sql` para reversión de infraestructura de roles.

---

## [0.2.9] - 2026-09-15
- Release de remediación auditado externamente (NO PASS — Dictamen de Auditoría Externa v0.2.9).

## [0.2.8] - 2026-09-15
- Release de remediación auditado externamente (NO PASS).

## [0.2.7] - 2026-09-15
- Release de remediación parcial auditado (NO PASS).

## [0.2.6] - 2026-09-15
- Release de remediación parcial auditado (NO PASS).

## [0.2.5] - 2026-09-15
- Release de remediación parcial auditado (NO PASS).

## [0.2.4] - 2026-09-15
- Release de remediación parcial auditado (NO PASS).

## [0.2.3] - 2026-09-15
- Release de remediación parcial auditado (NO PASS).

## [0.2.2] - 2026-09-15
- Release de remediación parcial auditado (NO PASS).

## [0.2.1] - 2026-09-15
- Release de remediación parcial auditado (NO PASS).

## [0.2.0] - 2026-09-15
- Línea base de arquitectura y gobernanza ratificada (NO PASS).

## [0.1.0] - 2026-09-15
- Release inicial de la Fase 0.
