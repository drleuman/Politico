# Walkthrough de Verificación de Auditoría — Política Canon v0.2.10

**Estado:** `VIGENTE (RATIFICACIÓN HUMANA)`  
**Fecha:** 2026-09-15  
**Paquete:** `politica-canon-v0.2.10`  

---

## 1. Verificación de Puntos Críticos de Auditoría v0.2.10

1. **Línea Base Executable PostgreSQL 16+ & Arnés de Pruebas (`db/migrations/`, `docker-compose.audit.yml`):**
   - DDL ejecutable completo en `0001_initial_schema.sql` (30 tablas, 25 políticas RLS, 9 triggers anti-CASCADE).
   - Provisioning seguro `db/bootstrap_roles.sql` para `app_owner`, `app_user` (con `NOBYPASSRLS` y `GRANT SELECT, INSERT, UPDATE, DELETE`), `audit_worker` y `audit_reader` sin contraseñas versionadas.
   - Entorno en contenedor `docker-compose.audit.yml` para PostgreSQL 16+ y Redis 7+.

2. **Modelo Unificado de Asignación de Roles (`role_assignments`, `src/auth/authorization.ts`):**
   - Tabla `role_assignments` como fuente de verdad autoritativa de asignaciones con `scope_type` (`ORGANIZATION`, `WORKSPACE`, `AUTHORITY_BODY`), `scope_id`, vigencia temporal y estado activo.
   - Restricción DDL en `workspace_memberships` e `invitations` impidiendo asignaciones directas de los cuatro roles sensibles.

3. **Función Transaccional de Doble Control (`db/migrations/0001_initial_schema.sql`):**
   - `grant_governance_role_transactional(p_organization_id, p_request_id)` verifica coincidencia de tenant, aplica `FOR UPDATE` sobre solicitud y aprobaciones 1 y 2, comprueba 4 identidades distintas, valida membresías organizativas activas en los 4 participantes y miembros en `GOVERNANCE_REGISTRY`, e inserta atómicamente el evento en `audit_outbox`.

4. **Worker Outbox Ejecutable & Verificación Criptográfica (`src/audit/worker.ts`):**
   - Módulo TypeScript ejecutable `src/audit/worker.ts` con canonicalización JSON JCS RFC 8785, savepoints por elemento (`SAVEPOINT item_sp`), reintentos para `FAILED` con `next_attempt_at`, cola de letras muertas y función `verifyAuditChainCrypted` que recalcula criptográficamente cada hash SHA-256 sobre el sobre JCS.

5. **Invariantes Editoriales & DDL Reforzado:**
   - Restricción `unique_org_doc_version_number` en `document_versions`, FKs compuestas exactas en `submissions`, `reviews` y `publication_events`, y restricciones `CHECK` condicionales por tipo de evento en publicaciones.

6. **Validador Semántico Self-Contained (`scratch/validate_v0.2.10.cjs`):**
   - Script ejecutable que compila e inicia las pruebas de autorización en TypeScript, verifica mediante SHA-256 la inmutabilidad de los 11 informes históricos y parsea dinámicamente el diagrama Mermaid identificando las **29 Entidades Conceptuales Únicas**.

---

## 2. Enlaces Relativos de Referencia

- Matriz de Remediación v0.2.10: [`../../REMEDIATION_MATRIX_v0.2.10.md`](../../REMEDIATION_MATRIX_v0.2.10.md)
- Informe de Validación v0.2.10: [`../../VALIDATION_REPORT_v0.2.10.md`](../../VALIDATION_REPORT_v0.2.10.md)
- Script de Validación Incluido: [`../../scratch/validate_v0.2.10.cjs`](../../scratch/validate_v0.2.10.cjs)
- Aceptación Final y Solicitud de Auditoría Externa: [`../../PHASE_0_FINAL_ACCEPTANCE.md`](../../PHASE_0_FINAL_ACCEPTANCE.md)
