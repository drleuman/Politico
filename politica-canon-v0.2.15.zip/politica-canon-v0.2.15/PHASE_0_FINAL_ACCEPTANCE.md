# Solicitud de Auditoría Externa Final — Política Canon v0.2.15

**Fecha:** 2026-09-15  
**Paquete Entregado:** `politica-canon-v0.2.15.zip`  
**Estado Solicitado:** `FASE 0 — PENDIENTE DE AUDITORÍA EXTERNA FINAL (v0.2.15)`  

---

## Declaración de Cierre de Remediación

El Órgano Promotor Humano y el Equipo Técnico declaran que la versión **v0.2.15** ha aplicado remediaciones reales, ejecutables, reproducibles y probadas sobre la totalidad de los hallazgos críticos (C-01 a C-07) y altos (H-01 a H-07) emitidos en el dictamen de auditoría v0.2.7.

### Entregables y Puntos Clave Remediados:

1. **Línea Base Executable PostgreSQL 16+ & Arnés de Pruebas (`db/migrations/`, `docker-compose.audit.yml`):**
   - Migración SQL ejecutable `0001_initial_schema.sql` con 30 tablas, 25 políticas RLS, 9 triggers y funciones almacenadas.
   - Script de provisioning seguro `db/bootstrap_roles.sql` para `app_owner`, `app_user` (con `NOBYPASSRLS` y `GRANT SELECT, INSERT, UPDATE, DELETE`), `audit_worker` y `audit_reader` sin contraseñas versionadas.
   - Entorno reproducible `docker-compose.audit.yml` para levantar PostgreSQL 16+ y Redis 7+.

2. **Modelo Unificado de Roles y Ámbitos (`role_assignments`, `src/auth/authorization.ts`):**
   - Tabla `role_assignments` como fuente de verdad autoritativa de asignaciones con `scope_type` (`ORGANIZATION`, `WORKSPACE`, `AUTHORITY_BODY`), `scope_id`, vigencia temporal y estado activo.
   - Restricción DDL `check_ws_direct_role` e `check_invitation_role` que impiden asignar roles sensibles sin pasar por doble control.

3. **Función de Doble Control Totalmente Hardened (`db/migrations/0001_initial_schema.sql`):**
   - `grant_governance_role_transactional(p_organization_id, p_request_id)` verifica coincidencia de tenant, aplica `FOR UPDATE` sobre solicitud y aprobaciones (orden 1 y 2 explícitos), comprueba 4 identidades distintas, valida membresías de organización activas en los 4 participantes y miembros activos en `GOVERNANCE_REGISTRY`, e inserta atómicamente el evento en `audit_outbox` dentro de la misma transacción.

4. **Worker Outbox Ejecutable & Verificación Criptográfica (`src/audit/worker.ts`):**
   - Módulo TypeScript ejecutable `src/audit/worker.ts` con canonicalización JSON JCS RFC 8785, savepoints por elemento (`SAVEPOINT item_sp`), reintentos para `FAILED` con `next_attempt_at`, cola de letras muertas y función `verifyAuditChainCrypted` que recalcula criptográficamente cada hash SHA-256 sobre el sobre JCS.

5. **Invariantes Editoriales & DDL Reforzado:**
   - Restricción `unique_org_doc_version_number` en `document_versions`, FKs compuestas exactas en `submissions`, `reviews` y `publication_events`, y restricciones `CHECK` condicionales por tipo de evento en publicaciones.

6. **Validador Semántico Self-Contained (`scratch/validate_v0.2.15.cjs`):**
   - Script ejecutable que compila e inicia las pruebas de autorización en TypeScript, verifica mediante SHA-256 la inmutabilidad de los 11 informes históricos y parsea dinámicamente el diagrama Mermaid identificando las **29 Entidades Conceptuales Únicas**.

---

## Solicitud de Dictamen Final

Se remite el paquete `politica-canon-v0.2.15.zip` para la evaluación y dictamen formal por parte del Auditor Externo. La Fase 1 permanece estrictamente **BLOQUEADA** hasta la emisión de un dictamen `PASS`.
