# Solicitud de Auditoría Externa Final — Política Canon v0.2.16

**Fecha:** 2026-09-16  
**Paquete Entregado:** `politica-canon-v0.2.16.zip`  
**Estado Solicitado:** `FASE 0 — PENDIENTE DE AUDITORÍA EXTERNA FINAL (v0.2.16)`  

---

## Declaración de Cierre de Remediación

El Órgano Promotor Humano y el Equipo Técnico declaran que la versión **v0.2.16** ha aplicado remediaciones reales, ejecutables, reproducibles y probadas sobre la totalidad de los hallazgos críticos (C-01, C-02) y altos (H-01, H-02, H-03) emitidos en el dictamen de auditoría v0.2.15.

### Entregables y Puntos Clave Remediados:

1. **Línea Base Executable PostgreSQL 16+ & Arnés de Pruebas (`db/migrations/`, `docker-compose.audit.yml`):**
   - Migración SQL ejecutable `0001_initial_schema.sql` con 30 tablas, 25 políticas RLS, 9 triggers y funciones almacenadas.
   - Script de provisioning seguro `db/bootstrap_roles.sql` para `app_owner`, `app_user` (con `NOBYPASSRLS`), `audit_worker` y `audit_reader` sin contraseñas versionadas.
   - Entorno reproducible `docker-compose.audit.yml` para levantar PostgreSQL 16+ y Redis 7+.

2. **Canonicalizador JCS RFC 8785 Ejecutable en PostgreSQL 16 (C-01):**
   - Función PL/pgSQL `jcs_utf16_sort_key(p_key TEXT)` que codifica puntos de código UTF-16 BE permitiendo ordenación RFC 8785 nativa en PostgreSQL 16 sin depender de `convert_to(..., 'UTF16BE')`.

3. **Votación Atómica y Quórum Colegiado Estricto (C-02):**
   - `cast_vote_transactional` inserta atómicamente el voto en `decision_votes`.
   - `approve_decision_transactional` evalúa la votación persistida y exige mayoría estricta de elegibles (`v_approve_votes > v_total_eligible / 2.0`). En 2 elegibles, 1 voto falla y 2 aprueban; en 4 elegibles, 3 votos aprueban.

4. **Worker Outbox Ejecutable & Verificación Criptográfica (`src/audit/worker.ts`):**
   - Módulo TypeScript ejecutable `src/audit/worker.ts` con canonicalización JSON JCS RFC 8785, savepoints por elemento (`SAVEPOINT item_sp`), reintentos para `FAILED` con `next_attempt_at`, cola de letras muertas y función `verifyAuditChainCrypted` que recalcula criptográficamente cada hash SHA-256 sobre el sobre JCS.

5. **Validador Semántico e Integración PostgreSQL 16 (`validate_v0.2.16.cjs`):**
   - Script ejecutable que compila e inicia las pruebas de autorización en TypeScript, verifica mediante SHA-256 la inmutabilidad de los 16 informes históricos y parsea dinámicamente el diagrama Mermaid identificando las **30 Entidades Conceptuales Únicas**.

---

## Solicitud de Dictamen Final

Se remite el paquete `politica-canon-v0.2.16.zip` y su manifiesto desacoplado `MANIFEST_v0.2.16.json` para la evaluación y dictamen formal por parte del Auditor Externo. La Fase 1 permanece estrictamente **BLOQUEADA** hasta la emisión de un dictamen `PASS`.
