# Walkthrough de Verificación de Auditoría — Política Canon v0.2.16

**Estado:** `VIGENTE (RATIFICACIÓN HUMANA)`  
**Fecha:** 2026-09-16  
**Paquete:** `politica-canon-v0.2.16`  

---

## 1. Verificación de Puntos Críticos de Auditoría v0.2.16

1. **Línea Base Executable PostgreSQL 16+ & Arnés de Pruebas (`db/migrations/`, `docker-compose.audit.yml`):**
   - DDL ejecutable completo en `0001_initial_schema.sql` (30 tablas, 25 políticas RLS, 9 triggers anti-CASCADE).
   - Provisioning seguro `db/bootstrap_roles.sql` para `app_owner`, `app_user` (con `NOBYPASSRLS`), `audit_worker` y `audit_reader` sin contraseñas versionadas.
   - Entorno en contenedor `docker-compose.audit.yml` para PostgreSQL 16+ y Redis 7+.

2. **Canonicalizador JCS RFC 8785 Ejecutable en PostgreSQL 16 (C-01):**
   - Función PL/pgSQL `jcs_utf16_sort_key(p_key TEXT)` para codificación UTF-16 BE permitiendo ordenación RFC 8785 nativa en PostgreSQL 16 sin depender de `convert_to(..., 'UTF16BE')`.

3. **Votación Atómica y Quórum Colegiado Estricto (C-02):**
   - `cast_vote_transactional` inserta atómicamente el voto en `decision_votes`.
   - `approve_decision_transactional` evalúa la votación persistida y exige mayoría estricta de elegibles (`v_approve_votes > v_total_eligible / 2.0`). En 2 elegibles, 1 voto falla y 2 aprueban; en 4 elegibles, 3 votos aprueban.

4. **Worker Outbox Ejecutable & Verificación Criptográfica (`src/audit/worker.ts`):**
   - Módulo TypeScript ejecutable `src/audit/worker.ts` con canonicalización JSON JCS RFC 8785, savepoints por elemento (`SAVEPOINT item_sp`), reintentos para `FAILED` con `next_attempt_at`, cola de letras muertas y función `verifyAuditChainCrypted` que recalcula criptográficamente cada hash SHA-256 sobre el sobre JCS.

5. **Validador Semántico e Integración PostgreSQL 16 (`validate_v0.2.16.cjs`):**
   - Script ejecutable que compila e inicia las pruebas de autorización en TypeScript, verifica mediante SHA-256 la inmutabilidad de los 16 informes históricos y parsea dinámicamente el diagrama Mermaid identificando las **30 Entidades Conceptuales Únicas**.

---

## 2. Enlaces Relativos de Referencia

- Matriz de Remediación v0.2.16: [`../../REMEDIATION_MATRIX_v0.2.16.md`](../../REMEDIATION_MATRIX_v0.2.16.md)
- Informe de Validación v0.2.16: [`../../VALIDATION_REPORT_v0.2.16.md`](../../VALIDATION_REPORT_v0.2.16.md)
- Script de Validación Incluido: [`../../validate_v0.2.16.cjs`](../../validate_v0.2.16.cjs)
- Aceptación Final y Solicitud de Auditoría Externa: [`../../PHASE_0_FINAL_ACCEPTANCE.md`](../../PHASE_0_FINAL_ACCEPTANCE.md)
