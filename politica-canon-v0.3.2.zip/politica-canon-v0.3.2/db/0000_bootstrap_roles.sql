-- ============================================================================
-- FASE 1: PRE-BOOTSTRAP DE ROLES Y GRUPOS DE SEGURIDAD CANÓNICOS (v0.3.2)
-- Ejecutar exclusivamente como SUPERUSUARIO ('postgres') antes de crear objetos
-- ============================================================================

DO $$
BEGIN
    -- 1. Rol Propietario de Esquema (app_owner)
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'app_owner') THEN
        CREATE ROLE app_owner WITH NOLOGIN NOINHERIT NOSUPERUSER NOCREATEDB NOCREATEROLE;
    END IF;

    -- 2. Rol Grupo de Usuario de Aplicación (app_user)
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'app_user') THEN
        CREATE ROLE app_user WITH NOLOGIN NOINHERIT NOSUPERUSER NOCREATEDB NOCREATEROLE NOBYPASSRLS;
    END IF;

    -- 3. Rol Grupo de Worker de Auditoría (audit_worker)
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'audit_worker') THEN
        CREATE ROLE audit_worker WITH NOLOGIN NOINHERIT NOSUPERUSER NOCREATEDB NOCREATEROLE NOBYPASSRLS;
    END IF;

    -- 4. Rol Grupo de Lectura de Auditoría (audit_reader)
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'audit_reader') THEN
        CREATE ROLE audit_reader WITH NOLOGIN NOINHERIT NOSUPERUSER NOCREATEDB NOCREATEROLE NOBYPASSRLS;
    END IF;

    -- 5. Rol Grupo de Despacho de Auditoría (audit_dispatcher)
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'audit_dispatcher') THEN
        CREATE ROLE audit_dispatcher WITH NOLOGIN NOINHERIT NOSUPERUSER NOCREATEDB NOCREATEROLE NOBYPASSRLS;
    END IF;

    -- 6. Rol de Conexión Runtime Específico del Servidor (politica_canon_app)
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'politica_canon_app') THEN
        CREATE ROLE politica_canon_app WITH LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOBYPASSRLS CONNECTION LIMIT 10;
    ELSE
        ALTER ROLE politica_canon_app WITH NOSUPERUSER NOCREATEDB NOCREATEROLE NOBYPASSRLS CONNECTION LIMIT 10;
    END IF;
END $$;

-- Enlazar la identidad de runtime al rol canónico app_user
GRANT app_user TO politica_canon_app;

-- Garantizar que app_user no pueda omitir RLS bajo ninguna circunstancia
ALTER ROLE app_user SET row_security = on;
ALTER ROLE politica_canon_app SET row_security = on;
