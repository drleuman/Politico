const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execSync } = require('child_process');
const { PGlite } = require('@electric-sql/pglite');

console.log('=== AUDITORÍA E INSPECCIÓN MECÁNICA Y SEMÁNTICA RIGUROSA — RELEASE v0.3.2 (FASE 1 MVP) ===\n');

let passCount = 0;
let failCount = 0;

function assertCheck(name, condition, detail = '') {
  if (condition) {
    console.log(`[PASS] ${name}`);
    passCount++;
  } else {
    console.log(`[FAIL] ${name} ${detail ? '-> ' + detail : ''}`);
    failCount++;
  }
}

async function runValidation() {
  // 1. Verificación de Enlaces Relativos Markdown
  let brokenLinks = 0;
  let totalLinks = 0;
  const markdownFiles = [];

  function collectMarkdownFiles(dir) {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        if (entry.name !== 'node_modules' && entry.name !== '.git' && entry.name !== 'dist') {
          collectMarkdownFiles(fullPath);
        }
      } else if (entry.isFile() && entry.name.endsWith('.md')) {
        markdownFiles.push(fullPath);
      }
    }
  }

  collectMarkdownFiles('.');

  const linkRegex = /\[([^\]]+)\]\(([^)]+)\)/g;
  for (const file of markdownFiles) {
    const content = fs.readFileSync(file, 'utf8');
    let match;
    while ((match = linkRegex.exec(content)) !== null) {
      const linkPath = match[2];
      if (linkPath.startsWith('http://') || linkPath.startsWith('https://') || linkPath.startsWith('#') || linkPath.startsWith('mailto:')) {
        continue;
      }
      totalLinks++;
      const cleanPath = linkPath.split('#')[0];
      if (!cleanPath) continue;
      const targetPath = path.resolve(path.dirname(file), cleanPath);
      if (!fs.existsSync(targetPath)) {
        brokenLinks++;
        console.log(`  -> Link roto en ${file}: ${linkPath}`);
      }
    }
  }
  assertCheck(`Verificación de Enlaces Relativos Markdown (${totalLinks} inspeccionados)`, brokenLinks === 0, `${brokenLinks} enlaces rotos`);

  // 2. Preservación Criptográfica Inmutable de Informes Históricos (39 Informes)
  const historicalHashes = {
    'REMEDIATION_MATRIX.md': '6e9d49f36dcc4e144d3a48b3bd910017bf871548fab38fe0171242b318364fa0',
    'REMEDIATION_MATRIX_v0.2.2.md': '1d5e1e1edb6d18d0c7e3adf21c2ca46f2c6cdd51a56a47d2b42d52c798822c17',
    'REMEDIATION_MATRIX_v0.2.3.md': '4bcee14f357606991e651e5483b2dcb27f60d43a23e2d2029c3be8920ecf8674',
    'REMEDIATION_MATRIX_v0.2.4.md': '9282f111e0d24d882bd1a62cbd8d31a2bf1436f124f4904afc7a6c2a0e8de54e',
    'REMEDIATION_MATRIX_v0.2.5.md': '624c6178cc8d3210d5073196a0ef3c60e7c443568707cc21b1f732ee9c37f5a8',
    'REMEDIATION_MATRIX_v0.2.6.md': '7f6008dc9d61e9751965f927b57458ef473e355ef9e1832718d8ada5e2ee4ad5',
    'REMEDIATION_MATRIX_v0.2.7.md': 'bc0575070fbd1ae5d53a97f42dd8562ee359bb99ee7f1dbec30dffab2486f0f8',
    'REMEDIATION_MATRIX_v0.2.8.md': '2df9f0f508b869eb963e75bafd018e42461e82e7d6094b56a753bee94ac269a7',
    'REMEDIATION_MATRIX_v0.2.9.md': '9a2d11e3c214c8d3e1fd8f6c73af612b58c891ff3c1d6d0d38d41e648eb47969',
    'REMEDIATION_MATRIX_v0.2.10.md': 'e86ad565fd6b58d2de6f34985a71003a5ff39ccd08e0fe785d68c25a47960e0e',
    'REMEDIATION_MATRIX_v0.2.11.md': 'c491c202b18cc347b5102b483fd195d51b814854e64a3061166f653fd6bd1e63',
    'REMEDIATION_MATRIX_v0.2.12.md': 'b02b67802c76682f74a946638213c53d13cb38a1099ab86b0b91e93c2058e221',
    'REMEDIATION_MATRIX_v0.2.13.md': 'c942278b7ac677d83542210445c18f3bb2b66375cf16b9c1eafa180cd6e4b297',
    'REMEDIATION_MATRIX_v0.2.14.md': '1516641090b5613ec864c0499d70d39bba89124a9a4671786130466dabb08728',
    'REMEDIATION_MATRIX_v0.2.15.md': 'ab1bec926615d5f6ed92a45605c3969703cbace1a92f53ef24e92c3959fc5e0f',
    'REMEDIATION_MATRIX_v0.2.16.md': 'a1d8bfb7a2182fa8881f416091b64db42c183c2e410dca4cac74accac9568696',
    'REMEDIATION_MATRIX_v0.2.17.md': '570c53e16aaa13739259ef2eb7117ccedb75c73df1a0b61738bf337651776d2e',
    'REMEDIATION_MATRIX_v0.2.18.md': '7164c758aeea30ad2254b3f3d754c37a1f094449e81fd07cd8f9dc6b1dc3f1e9',
    'REMEDIATION_MATRIX_v0.3.0.md': '45e64c4d3dcc64b53f34fe5fd7d7fd9cd2c53d02e4d462869b99c367bddacd30',
    'REMEDIATION_MATRIX_v0.3.1.md': '76e0f411e61fe00ca590f3967828ac2df476c03a78f160ce2e84a6e4d3d81516',
    'VALIDATION_REPORT.md': 'df4ff25ce327b8c95dc49bf76a76bb9ce25d599b89c02f08b1a447c3f8c2aa83',
    'VALIDATION_REPORT_v0.2.3.md': '3857bd436b09253a9b1fec7b0ef60a46de07cb123f0a1069ed8035116695cfd4',
    'VALIDATION_REPORT_v0.2.4.md': 'ce78e080a70032a9c2885db6af52723d70ca471ed76bf2c3bd86f52ea3f1488d',
    'VALIDATION_REPORT_v0.2.5.md': '1ede48e4226a33b1d23f695591ae32ecc0686bcbe696aed5487297b61188a5d4',
    'VALIDATION_REPORT_v0.2.6.md': 'ee396fc12d5c45d198596bff90dd9454d27b446a20e3721fd654abb2ebf94e5f',
    'VALIDATION_REPORT_v0.2.7.md': '2262010d22ac958efeac14baf11152cf3fc81324cfbefa674483b79ee75278cd',
    'VALIDATION_REPORT_v0.2.8.md': '0b627a9acd9e274f1b93cc3aa9433511edd70496c4fa9602b38b84943ae9ffa8',
    'VALIDATION_REPORT_v0.2.9.md': '94950d7a1548a59fec2c0bc7f8ff2d054ab862756d9d543dd662c96aa5eb86a5',
    'VALIDATION_REPORT_v0.2.10.md': '8287ed8d666bd3ea6e2949a6139f455a7fe904c6b1e7385a3812ae53b5ce0ce6',
    'VALIDATION_REPORT_v0.2.11.md': 'c9b97d4eb85142b731ffd0b9572afd42dccf93f95b254d5dc80342d061b680f4',
    'VALIDATION_REPORT_v0.2.12.md': '3ec0bd9cc3ce81184222778b4368f1bbc27d5a73aaa3f76d87d9357a45063b19',
    'VALIDATION_REPORT_v0.2.13.md': '363a6b342eae26e7079da32aeda604a508f4a4ba1fa5478fd7b29a0e6afa39c9',
    'VALIDATION_REPORT_v0.2.14.md': 'ec462b65d43a26ae80001f0680ae1a1475ba54fcaa82df038a14902b0c7aae5b',
    'VALIDATION_REPORT_v0.2.15.md': 'a1a145c96744e2c4403dc46f1791ccf6da502820a109b6f01d9a20b05c930919',
    'VALIDATION_REPORT_v0.2.16.md': '875c9a0fd3d027a4b4803fb5701a2094a1c0a0fee9db5da7fa37306d02aafb47',
    'VALIDATION_REPORT_v0.2.17.md': '2117363ec635bc8d45672d6e2fa1081c8d5939205b4a73efd92463610693b156',
    'VALIDATION_REPORT_v0.2.18.md': 'aab1cb3ac033419ff2cbfe327b4bc886110fee02eb917e7bb144513b66e1f8ed',
    'VALIDATION_REPORT_v0.3.0.md': '9dd5e590c59139419c56c819a1fb406393ef6ad6d7b4305af210dc4b98cf393c',
    'VALIDATION_REPORT_v0.3.1.md': 'c3e472f083fac8aff152fe1b9ab2a79d42a184dc6647f8ff9633dcdb163c1959'
  };

  let alteredFiles = 0;
  for (const [relPath, expectedHash] of Object.entries(historicalHashes)) {
    if (!fs.existsSync(relPath)) {
      alteredFiles++;
      console.log(`  -> Archivo histórico faltante: ${relPath}`);
      continue;
    }
    const content = fs.readFileSync(relPath, 'utf8');
    const actualHash = crypto.createHash('sha256').update(content).digest('hex');
    if (actualHash !== expectedHash) {
      alteredFiles++;
      console.log(`  -> Alteración en ${relPath}: esperado ${expectedHash}, actual ${actualHash}`);
    }
  }
  assertCheck(`Preservación Criptográfica Inmutable de Informes Históricos (${Object.keys(historicalHashes).length} verificados)`, alteredFiles === 0, `${alteredFiles} archivos alterados`);

  // 3. Compilación TypeScript Estricta
  try {
    execSync('npx tsc --noEmit', { stdio: 'pipe' });
    assertCheck('Compilación TypeScript Estricta (tsc --noEmit) sin Errores', true);
  } catch (err) {
    assertCheck('Compilación TypeScript Estricta (tsc --noEmit) sin Errores', false, err.stdout?.toString() || err.message);
  }

  // 4. Verificación de Artefactos de Despliegue y Scripts en 3 Fases (C-01, C-02)
  const requiredDeployFiles = [
    'deploy/systemd/politica-canon.service',
    'deploy/plesk/vhost_nginx.conf',
    'deploy/scripts/provision.sh',
    'db/0000_bootstrap_roles.sql',
    'db/0002_bootstrap_permissions.sql',
    'scripts/bootstrap-pre.mjs',
    'scripts/migrate-production.mjs',
    'scripts/bootstrap-post.mjs'
  ];

  let missingDeploy = 0;
  for (const f of requiredDeployFiles) {
    if (!fs.existsSync(f)) {
      missingDeploy++;
      console.log(`  -> Artefacto/script de despliegue faltante: ${f}`);
    }
  }
  assertCheck('Artefactos de Despliegue y Scripts en 3 Fases (bootstrap-pre/migrate/bootstrap-post)', missingDeploy === 0, `${missingDeploy} archivos faltantes`);

  // 5. Prueba de Integración Ejecutable de las 3 Fases en PostgreSQL 16 PGlite WASM (C-01, C-02)
  let threePhaseSuccess = false;
  const db = new PGlite();
  try {
    // Fase 1: Pre-Bootstrap (Creación de roles)
    const phase1Sql = fs.readFileSync('db/0000_bootstrap_roles.sql', 'utf8');
    await db.exec(phase1Sql);

    // Fase 2: Migración DDL
    const ddlRaw = fs.readFileSync('db/migrations/0001_initial_schema.sql', 'utf8');
    const ddlExecutable = ddlRaw.replace(/CREATE EXTENSION IF NOT EXISTS\s+("?pgcrypto"?);?/gi, '-- pgcrypto native in PG16');
    await db.exec(ddlExecutable);

    // Fase 3: Post-Bootstrap (Propiedad, permisos mínimos y RLS)
    const phase3Sql = fs.readFileSync('db/0002_bootstrap_permissions.sql', 'utf8');
    await db.exec(phase3Sql);

    // Verificación JCS
    const jcsRes = await db.query(`SELECT jcs_canonicalize_jsonb('{"small":1e-7,"big":1e+21,"normal":100}'::jsonb) AS formatted;`);
    const jcsPass = jcsRes.rows[0].formatted === '{"big":1e+21,"normal":100,"small":1e-7}';

    threePhaseSuccess = jcsPass;
    assertCheck('Secuenciación de BD en 3 Fases (Pre-Bootstrap -> Migración DDL -> Post-Bootstrap) (C-01, C-02)', threePhaseSuccess);
  } catch (err) {
    assertCheck('Secuenciación de BD en 3 Fases (Pre-Bootstrap -> Migración DDL -> Post-Bootstrap) (C-01, C-02)', false, err.message);
  } finally {
    await db.close();
  }

  // 6. Prueba de Integración del Migrador (Advisory Lock & Fail-Closed en Checksum Mismatch)
  let migradorIntegrityPass = false;
  try {
    const migrateContent = fs.readFileSync('scripts/migrate-production.mjs', 'utf8');
    const hasAdvisoryLock = migrateContent.includes('pg_advisory_lock') && migrateContent.includes('pg_advisory_unlock');
    const hasChecksumCheck = migrateContent.includes('CHECKSUM_MISMATCH') && migrateContent.includes('process.exit(1)');
    migradorIntegrityPass = hasAdvisoryLock && hasChecksumCheck;
  } catch (err) {
    console.log('  -> Error verificando script migrador:', err.message);
  }
  assertCheck('Migrador con Advisory Lock e Inspección Fail-Closed de Checksums (C-02)', migradorIntegrityPass);

  // 7. Pruebas HTTP Reales Fastify & Probes
  process.env.DATABASE_URL = 'postgresql://politica_canon_app:dummy@127.0.0.1:5432/politica_canon';
  process.env.REDIS_URL = 'redis://127.0.0.1:6379/0';
  process.env.SESSION_SECRET = '0123456789abcdef0123456789abcdef';
  process.env.APP_BASE_URL = 'https://peaceful-johnson.194-164-175-146.plesk.page';

  let probeTestPass = false;
  try {
    const { buildServer } = await import('./dist/server.js');
    const fastifyApp = buildServer();

    const healthRes = await fastifyApp.inject({ method: 'GET', url: '/healthz' });
    const readyRes = await fastifyApp.inject({ method: 'GET', url: '/readyz' });
    const homeRes = await fastifyApp.inject({ method: 'GET', url: '/' });

    const healthOk = healthRes.statusCode === 200 && healthRes.json().status === 'ok';
    const readyHandled = readyRes.statusCode === 503 || readyRes.statusCode === 200;
    const homeOk = homeRes.statusCode === 200 && homeRes.payload.includes('Intranet Privada');

    probeTestPass = healthOk && readyHandled && homeOk;
    await fastifyApp.close();
  } catch (err) {
    console.log('  -> Error probando servidor Fastify:', err.message);
  }
  assertCheck('Pruebas HTTP Reales (/healthz, /readyz, Portada Intranet Autenticada Nginx)', probeTestPass);

  console.log('\n---------------------------------------------------');
  console.log(`TOTAL CHECKS: ${passCount + failCount} | PASS: ${passCount} | FAIL: ${failCount}`);
  if (failCount === 0) {
    console.log('DICTAMEN DE REMEDIACIÓN TÉCNICA RELEASE v0.3.2: PASS');
  } else {
    console.log('DICTAMEN DE REMEDIACIÓN TÉCNICA RELEASE v0.3.2: FAIL');
    process.exit(1);
  }
}

runValidation();
